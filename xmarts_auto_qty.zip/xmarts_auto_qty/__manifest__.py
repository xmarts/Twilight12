{
    'name': 'Xmarts auto qty  1',
    'version': '11.0.3',
    'category': "",
    'description': """ Set qty = 1 when selecting a product in an order line.
    """,
    'author':'Axel',
    'depends': ['base','sale'],
    'data': [
	

    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,

}
