{
    'name': 'Xmarts Reporte invoice ',
    'version': '11.0.3',
    'category': "",
    'description': """ invoice Report 
    """,
    'author':'Axel  God',
    'depends': ['base','account'],
    'data': [
	
	
	"report/invoice_report.xml",
	  
    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
    "images":['static/src/img/banco.png'],
}
