{
    'name': 'Xmarts credit limit custom ',
    'version': '11.0.3',
    'category': 'Sales Management',
    'description': """ Muestra la cantidad disponible en sale order
    """,
    'author':'Axel',
    'depends': ['sale','credit_limit_alert'],
    'data': [
	'views/sale_view.xml',


	  
    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
}
