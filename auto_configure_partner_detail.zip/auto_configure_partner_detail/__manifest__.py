{
    'name': 'Auto Configure Phone Email in Sale Order',
    'version': '11.0.3',
    'category': 'Sales Management',
    'description': """ Customization in Sale Order
    """,
    'author':'Vraja Technologies',
    'depends': ['sale','base'],
    'data': [
        'views/sale_view.xml',
    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
}
