# -*- coding: utf-8 -*-
{
    'name': 'Xmarts Reporte follow up ',
    'version': '11.0.3',
    'category': "",
    'description': """ follow up Report 
    """,
    'author':'Axel',
    'depends': ['base'],
    'data': [
	

	  
    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
}
