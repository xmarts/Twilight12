{
    'name': 'Xmarts Tipo de Cambio ',
    'version': '11.0.3',
    'category': "",
    'description': """ get data from currency_id 
    """,
    'author':'Axel indian God',
    'depends': ['account'],
    'data': [

	  
    ],
    'qweb': [
        ],
    'demo': [],
    'test': [],
    'installable': True,
    'auto_install': False,
}
